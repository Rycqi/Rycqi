# EZFN

This is a Private Server made for EZFN.DEV<br>
We would be happy if you credit us when using this ❤️

## Installation 
* **[Download](https://github.com/EZFNDEV/FNPrivateServer/releases/latest/download/EZFNLauncher.zip)** the latest version.
* **Unzip the Folder** to somewhere on your PC and launch "FortniteLauncher.exe"
  * You now need to enter the Email address and password for your **EZFN** account (https://ezfn.dev)
  
## Features
✔️ Access all cosmetics<br>
✔️ View the Item Shop<br>
✔️ Dashboard to edit your account settings<br>
▶️ IN PROGRESS: Join others who use this Private Server<br>

#### Credits
The Launcher that is used is based on the AuroraLauncher made by Cyuubi and Slushia
